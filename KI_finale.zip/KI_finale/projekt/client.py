import pygame
import json
import subprocess
from network import Network

pygame.font.init()

def compute_move_with_java(board_str):
    # point to your GuardAndTowers-1.0-jar-with-dependencies.jar
    jar_path = r"C:\Users\msii\Downloads\KI_finale\projekt\src\Game.jar"
    try:
        proc = subprocess.run(
            ["java", "-jar", jar_path, board_str],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5
        )
    except subprocess.TimeoutExpired:
        raise RuntimeError("Java AI timed out")
    if proc.returncode != 0:
        print("Java AI error:", proc.stderr)
        raise RuntimeError("Java AI failed")
    return proc.stdout.strip()  # e.g. "A7-B7-1"

def main():
    run = True
    clock = pygame.time.Clock()
    n = Network()
    player = int(n.getP())
    print("You are player", player)

    while run:
        clock.tick(60)
        try:
            raw = n.send(json.dumps("get"))
            if raw is None:
                raise ValueError("No game data")
            game = json.loads(raw)
        except Exception as e:
            print("Network error:", e)
            break

        if not game["bothConnected"]:
            continue

        # only act on your turn
        your_turn = (player == 0 and game["turn"] == "r") or \
                    (player == 1 and game["turn"] == "b")
        if your_turn:
            print("Board:", game["board"], " Time left:", game["time"])
            try:
                move_str = compute_move_with_java(game["board"])
            except Exception as e:
                print("AI fallback due to:", e)
                # pick a safe no-op or resign move
                move_str = "A7-B7-1"
            print("→ sending move:", move_str)
            n.send(json.dumps(move_str))

if __name__ == "__main__":
    main()
