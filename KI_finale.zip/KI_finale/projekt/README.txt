ISIS-Gruppennummer : V 

Mitglieder:
- Achraf Akremi (468020)
- Mohamed Hedi Ben Brahim (497843)
- Mohamed Rami Ben Moussa (494538)
- Rami Zayati (487291)

Schritte zum Ausführen des Projekts:
Öffnen Sie direkt die Game.jar. Die JAR-Datei finden Sie im src-Ordner.

oder:

1- Wechseln Sie in das Verzeichnis src, sodass der Pfad in Ihrem Terminal ..\src lautet.
2- Führen Sie dann folgenden Befehl aus:  javac main/*.java pieces/*.java benchmark/*.java game/*.java ki/*.java  
3- Geben Sie dann folgenden Befehl ein: java main.Main
4- Dann öffnet sich ein Fenster. Wählen Sie einfach aus: Human vs Computer
5- Dann folgen weitere Fragen: Wählen Sie die Farbe der KI und geben Sie einen FEN-String für einen Spielzustand an. 
Möchten Sie einen bestimmten Zustand wählen, geben Sie diesen ein; andernfalls drücken Sie einfach „OK“ – dann wird
standardmäßig der Anfangszustand verwendet.




Für die Verbindung zum Gameserver:
nutzen Sie bitte unsere angepasste Client.py. Die geänderte Datei finden Sie im Ordner ..\projekt.
Wichtig:

Bevor Sie client.py ausführen, passen Sie bitte den Parameter path_jar an, damit auf unsere Game.jar im korrekten Verzeichnis verwiesen wird.
Den Eintrag path_jar finden Sie am Anfang der Funktion:
def compute_move_with_java(board_str):
    # hier steht path_jar = ...
    # zb : jar_path = r"C:\Users\msii\Downloads\projekt\src\Game.jar"
Passen Sie dort den Pfad entsprechend an. 